package com.kafka.dto;

public class MobileOrderDto {
	//id, mobile vendor, model, price, order placement date, customer name, customer email, customer mobile
}
