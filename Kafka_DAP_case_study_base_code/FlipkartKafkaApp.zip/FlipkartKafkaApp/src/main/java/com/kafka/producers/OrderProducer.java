package com.kafka.producers;

//OrderProducer should use thread pool with Java executor framework to continuously produce Book orders, Car orders & Mobile orders
//Every order's properties should be randomly generated using Random class
public class OrderProducer {

	public static void main(String args[]) {
		
	}
}
