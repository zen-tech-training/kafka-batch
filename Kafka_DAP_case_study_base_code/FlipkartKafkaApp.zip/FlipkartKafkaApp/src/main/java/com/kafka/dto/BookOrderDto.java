package com.kafka.dto;

public class BookOrderDto {
	//id, book title, book author, price, order placement date, customer name, customer email, customer mobile
}
