package com.kafka.deserializers;

import org.apache.kafka.common.serialization.Deserializer;

import com.kafka.dto.MobileOrderDto;

public class MobileOrderDeserializer implements Deserializer<MobileOrderDto>{

	@Override
	public MobileOrderDto deserialize(String topic, byte[] data) {
		return null;
	}

}
