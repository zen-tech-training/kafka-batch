package com.kafka.deserializers;

import org.apache.kafka.common.serialization.Deserializer;

import com.kafka.dto.CarOrderDto;

public class CarOrderDeserializer implements Deserializer<CarOrderDto>{

	@Override
	public CarOrderDto deserialize(String topic, byte[] data) {
		return null;
	}

}
