package com.kafka.deserializers;

import org.apache.kafka.common.serialization.Deserializer;

import com.kafka.dto.BookOrderDto;

public class BookOrderDeserializer implements Deserializer<BookOrderDto>{

	@Override
	public BookOrderDto deserialize(String topic, byte[] data) {
		return null;
	}

}
