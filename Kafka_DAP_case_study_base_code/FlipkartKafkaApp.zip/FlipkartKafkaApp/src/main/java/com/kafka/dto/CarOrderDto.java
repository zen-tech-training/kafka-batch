package com.kafka.dto;

public class CarOrderDto {
	//id, car vendor, model, color, price, order placement date, customer name, customer email, customer mobile
}
