package com.kafka.processors;

//BookOrderProcessor should process the book orders from "OrdersTopic" of Book category only.
//It should find out Books_order_count & Books_total_transaction_amount
public class BookOrderProcessor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
