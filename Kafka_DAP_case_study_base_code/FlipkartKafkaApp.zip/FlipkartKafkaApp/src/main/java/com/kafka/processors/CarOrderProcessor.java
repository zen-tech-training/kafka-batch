package com.kafka.processors;

//CarOrderProcessor should process the car orders from "OrdersTopic" of Car category only.
//It should find out Cars_order_count & Cars_total_transaction_amount
public class CarOrderProcessor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
