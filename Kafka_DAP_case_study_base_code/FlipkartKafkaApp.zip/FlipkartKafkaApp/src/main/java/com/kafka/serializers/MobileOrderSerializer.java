package com.kafka.serializers;

import org.apache.kafka.common.serialization.Serializer;

import com.kafka.dto.MobileOrderDto;

public class MobileOrderSerializer implements Serializer<MobileOrderDto>{

	@Override
	public byte[] serialize(String topic, MobileOrderDto data) {
		return null;
	}

}
