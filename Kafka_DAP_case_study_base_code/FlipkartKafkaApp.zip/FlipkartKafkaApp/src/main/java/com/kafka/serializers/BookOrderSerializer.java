package com.kafka.serializers;

import org.apache.kafka.common.serialization.Serializer;

import com.kafka.dto.BookOrderDto;

public class BookOrderSerializer implements Serializer<BookOrderDto>{

	@Override
	public byte[] serialize(String topic, BookOrderDto data) {
		return null;
	}

}
