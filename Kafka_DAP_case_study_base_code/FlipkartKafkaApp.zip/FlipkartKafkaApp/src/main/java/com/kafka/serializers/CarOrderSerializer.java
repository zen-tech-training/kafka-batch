package com.kafka.serializers;

import org.apache.kafka.common.serialization.Serializer;

import com.kafka.dto.CarOrderDto;

public class CarOrderSerializer implements Serializer<CarOrderDto>{

	@Override
	public byte[] serialize(String topic, CarOrderDto data) {
		return null;
	}

}
