package com.kafka.consumers;

//OrderReportConsumer should consume aggregated order report from "ReportTopic"
public class OrderReportConsumer {

	public static void main(String args[]) {
		
	}
}
