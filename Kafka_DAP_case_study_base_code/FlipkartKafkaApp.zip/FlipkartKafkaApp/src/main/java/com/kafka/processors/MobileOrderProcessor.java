package com.kafka.processors;

//MobileOrderProcessor should process the mobile orders from "OrdersTopic" of Mobile category only.
//It should find out Mobiles_order_count & Mobiles_total_transaction_amount
public class MobileOrderProcessor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
